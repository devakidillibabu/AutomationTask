package com.managers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.enums.BrowserType;
import com.managers.FileReaderManager;
import com.enums.Environments;

public class DriverManager {

	private static WebDriver driver;
	private static BrowserType browserType=FileReaderManager.getInstance().getPropertyReader().getBrowser();
 	private static Environments environmentType=FileReaderManager.getInstance().getPropertyReader().getEnvironment();
 	private static final String CHROME_DRIVER_PROPERTY = "webdriver.chrome.driver";
 	
	public static WebDriver getDriver() {
		if(driver == null) {
			driver = createDriver();
		}
		return driver;
	}
	
	private static WebDriver createDriver() {
		switch (environmentType) {     
         	case LOCAL : driver = createLocalDriver();
         	break;
         	case REMOTE : driver = createRemoteDriver();
         	break;
		}
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		return driver;
	}
	
	private static WebDriver createRemoteDriver() {
		throw new RuntimeException("RemoteWebDriver is not yet implemented");
	}
 
	private static WebDriver createLocalDriver() {
        switch (browserType) {     
        	case FIREFOX : driver = new FirefoxDriver();
        		break;
        	case CHROME :
        		System.setProperty(CHROME_DRIVER_PROPERTY, "src//main//resources//com//drivers//chromedriver.exe");
        		driver = new ChromeDriver();
        		break;
        	case INTERNETEXPLORER : driver = new InternetExplorerDriver();
        		break;
        }
        driver.manage().window().maximize();
        return driver;
	} 
	
	public static void quitDriver() {
		if(null!=driver) {
			driver.quit();
			driver = null;
		}
	}
	
	public static WebDriver getDriver(BrowserType BROWSERNAME) {
		browserType = BROWSERNAME;
		System.out.println("get Driver");
		if(driver == null) driver = createDriver();
		return driver;
	}
	
}
