package com.managers;

import com.pages.AmazonHomePage;
import com.pages.BooksCategoryPage;
import com.pages.BooksHomePage;

public class PageObjectManager {
	private AmazonHomePage amazonHomePage;
	private BooksHomePage booksHomePage;
	private BooksCategoryPage booksCategoryPage;
	private TestContext testContext;

	public AmazonHomePage getAmazonHomePage() {
		return (amazonHomePage == null) ? amazonHomePage = new AmazonHomePage() : amazonHomePage;
	}
	
	public BooksHomePage getBooksHomePage() {
		return (booksHomePage == null)	?	booksHomePage = new BooksHomePage() : booksHomePage;
	}
	
	public TestContext getTestContext() {
		return (testContext == null)	?	testContext = new TestContext() : testContext;
	}
	
	public BooksCategoryPage getBooksCategoryPage() {
		return (booksCategoryPage == null)	?	booksCategoryPage = new BooksCategoryPage()	:	booksCategoryPage;
	}
}
