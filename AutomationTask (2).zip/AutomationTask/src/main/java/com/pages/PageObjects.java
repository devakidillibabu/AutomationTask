package com.pages;

import org.openqa.selenium.support.PageFactory;
import com.managers.DriverManager;

public class PageObjects {
	public PageObjects() {
		PageFactory.initElements(DriverManager.getDriver(), this);
	}
}
