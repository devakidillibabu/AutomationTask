package com.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class BooksHomePage extends PageObjects{
	@FindAll(@FindBy(css="div.books-category ul li a")) private List<WebElement> lnkCategory;

	public List<String> getCategoryName(){
		List<String> getCategoryName = new ArrayList<String>();
		for(int i=0;i<this.lnkCategory.size();i++) {
			getCategoryName.add(this.lnkCategory.get(i).getText());
		}
		return getCategoryName;
	}
	
	public void clickCategoryName(String categoryName) {
		for(int i=0;i<this.lnkCategory.size();i++) {
			if(getCategoryName().get(i).trim().equalsIgnoreCase(categoryName)){
				this.lnkCategory.get(i).click();
				return;
			}
		}
	}
}
