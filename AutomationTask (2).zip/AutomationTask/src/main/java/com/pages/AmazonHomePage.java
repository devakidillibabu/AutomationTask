package com.pages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.managers.DriverManager;
import com.managers.FileReaderManager;
public class AmazonHomePage extends PageObjects{
	@FindBy(id="twotabsearchtextbox") private WebElement txtSearch;
	@FindBy(id="nav-search-submit-text") private WebElement btnSearch;
	@FindBy(tagName="a") private List<WebElement> urlLinks;
	@FindBy(tagName="img") private List<WebElement> imgLinks;

	
	
	public void enterSearchText(String searchText) {
		this.txtSearch.sendKeys(searchText);
	}
	
	public void clickSearch() {
		this.btnSearch.click();
	}
	
	public List<String> getAllUrl() {
		List getAllUrl = new ArrayList();
		for(int i=0;i<this.urlLinks.size();i++)
		{
			
			WebElement ele= this.urlLinks.get(i);
			
			String url=ele.getAttribute("href");
			if(url!=null) {
				getAllUrl.add(url);				
			}
			
		}
	
        return getAllUrl;
	}
}
