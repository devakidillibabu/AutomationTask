package com.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class BooksCategoryPage extends PageObjects{
	@FindBy(css="div.category-head h1") public WebElement txtCategoryHeader;
	
	public WebElement getCategoryHeader() {
		return this.txtCategoryHeader;
	}
}
