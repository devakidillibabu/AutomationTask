package com.enums;

public enum BrowserType {
	CHROME,
	FIREFOX,
	INTERNETEXPLORER,
	EDGE
}
