package com.enums;

public enum Environments {
	LOCAL,
	REMOTE,
}
