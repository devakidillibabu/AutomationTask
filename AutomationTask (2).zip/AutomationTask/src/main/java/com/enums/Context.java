package com.enums;

public enum Context {
	CATEGORY_NAME;
}
