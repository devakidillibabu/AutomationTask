package com.config;

import com.managers.DriverManager;
import com.managers.PageObjectManager;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	public static PageObjectManager pageObjectManager;
	@Before
	public void setUp() {
		DriverManager.getDriver();
		pageObjectManager= new PageObjectManager();
	}
	@After
	public void tearDown() {

//		DriverManager.getDriver().manage().deleteAllCookies();
//		DriverManager.getDriver().quit();
	}
}
