package com.stepdefinitions;

import com.enums.Context;
import com.managers.TestContext;

import io.cucumber.java.en.*;

public class SearchByCategory extends StepDefinition{
	@When("I search by Category Name {string}")
	public void i_search_by_Category_Name(String CATEGORYNAME) {
		testContext.getScenarioContext().setContext(Context.CATEGORY_NAME, CATEGORYNAME);
		booksHomePage.clickCategoryName(CATEGORYNAME);
	}

	@Then("I verify category page is loaded successfully")
	public void i_verify_category_page_is_loaded_successfully() {
		Object categoryName = testContext.getScenarioContext().getContext(Context.CATEGORY_NAME);
		getAssertion().isTextPresent(booksCategoryPage.getCategoryHeader(),categoryName.toString());
	}
}
