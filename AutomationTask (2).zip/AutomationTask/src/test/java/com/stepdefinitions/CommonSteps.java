package com.stepdefinitions;

import com.managers.DriverManager;
import com.managers.FileReaderManager;

import io.cucumber.java.en.Given;

public class CommonSteps {
	@Given("I navigate to the books application")
	public void i_navigate_to_the_books_application() {
		try {
			DriverManager.getDriver().get(FileReaderManager.getInstance().getPropertyReader().getBooksApplicationUrl());
		}
		catch(Exception e){
			e.getMessage();
		}
	}
}
