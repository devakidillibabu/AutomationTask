package com.stepdefinitions;

import com.common.HttpResponseCode;
import com.common.VerifyBrokenLinks;
import com.enums.BrowserType;
import com.managers.DriverManager;
import com.managers.FileReaderManager;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

public class ValidateUrl extends StepDefinition{
	@When("^I navigate to the \"([^\"]*)\" in the given \"([^\"]*)\"$")
	public void i_navigate_to_the_in_the_given(String url,String browser){
		try
		{	
			int statusCode;
			statusCode = new HttpResponseCode().httpResponseCodeViaGet(url);
			DriverManager.getDriver(BrowserType.valueOf(browser.toUpperCase())).get(url);

			if(200 != statusCode) {
				System.out.println(url + " gave a response code of " + statusCode);
			}
		}
		catch(Exception e){
			e.getMessage();
		}
		
	}

	@Then("^I verify \"([^\"]*)\" is successfully loaded$")
	public void i_verify_is_successfully_loaded(String url) {
	   try 
	   {	
		   Assert.assertTrue(url.contains(DriverManager.getDriver().getCurrentUrl()));
		   System.out.println("Navigated to correct webpage");
	      
	   }
	   catch(Throwable pageNavigationError)
	   {
		   System.out.println("Didn't navigate to correct webpage");
	   }
	}
	
	@And("I close the browser")
	public void i_close_the_browser() {
		DriverManager.quitDriver();
	}
	
	@Given("^I navigate to the application$")
	public void i_navigate_to_the_application() {
		try {
			DriverManager.getDriver().get(FileReaderManager.getInstance().getPropertyReader().getApplicationUrl());
		}
		catch(Exception e){
			e.getMessage();
		}
	}
	
	
	@Then("^I verify the broken links$")
	public void i_verify_the_broken_links(){
		try {
			System.out.println(amazonHomePage.getAllUrl().size());
			for(int i=0;i<amazonHomePage.getAllUrl().size();i++) {
				System.out.println(amazonHomePage.getAllUrl().get(i));
				new VerifyBrokenLinks().isLinkBroken(amazonHomePage.getAllUrl().get(i));
			}
		}
			catch(Exception e) {
				e.getMessage();
			}
		
	}
	
	@When("I search for the text {string} in the searchbox")
	public void i_search_for_the_text_in_the_searchbox(String searchText) {
		try {
			amazonHomePage.enterSearchText(searchText);
		}
		catch(Exception e) {
			e.getMessage();
		}
	}
	@And("^I click on the search button$")
	public void i_click_on_the_search_button() {
		try {
			amazonHomePage.clickSearch();
		}
		catch(Exception e) {
			e.getMessage();
		}
	}
}
