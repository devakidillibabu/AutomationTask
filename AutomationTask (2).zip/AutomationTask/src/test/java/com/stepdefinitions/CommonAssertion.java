package com.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

public class CommonAssertion {
	
	public boolean isTextPresent(WebElement actual, String expected) throws NoSuchElementException 
	{
	    return actual.getText().contains(expected);
	}
}
