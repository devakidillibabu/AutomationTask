package com.stepdefinitions;

import com.config.Hooks;
import com.managers.TestContext;
import com.pages.AmazonHomePage;
import com.pages.BooksCategoryPage;
import com.pages.BooksHomePage;

public class StepDefinition {
	protected AmazonHomePage amazonHomePage;
	protected BooksHomePage booksHomePage;
	public TestContext testContext;
	private CommonVerification commonVerfication;
	protected BooksCategoryPage booksCategoryPage;
	public CommonAssertion commonAssertion;
	
	public StepDefinition() {
		amazonHomePage = Hooks.pageObjectManager.getAmazonHomePage();
		booksHomePage = Hooks.pageObjectManager.getBooksHomePage();
		booksCategoryPage = Hooks.pageObjectManager.getBooksCategoryPage();
		testContext = Hooks.pageObjectManager.getTestContext();
		
	}
	public CommonVerification getVerification() {
		return (commonVerfication == null)	?	commonVerfication = new CommonVerification() : commonVerfication;
	}
	
	public CommonAssertion getAssertion() {
		return (commonAssertion == null)	?	commonAssertion = new CommonAssertion() : commonAssertion;
	}

}
