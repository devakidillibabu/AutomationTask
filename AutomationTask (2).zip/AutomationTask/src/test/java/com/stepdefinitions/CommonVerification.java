package com.stepdefinitions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.managers.DriverManager;

public class CommonVerification {

	public void visibilityOfElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 15);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	

}
